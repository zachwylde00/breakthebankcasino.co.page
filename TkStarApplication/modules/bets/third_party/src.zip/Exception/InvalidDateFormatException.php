<?php

namespace Sportmonks\Soccer\Exception;

use Exception;

/**
 * Class InvalidDateFormatException
 * @package Sportmonks\Soccer\Exception
 */
class InvalidDateFormatException extends Exception
{
}
