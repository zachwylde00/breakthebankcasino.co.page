<?php

namespace Sportmonks\Soccer\Exception;

use Exception;

/**
 * Class ApiRequestException
 * @package Sportmonks\Soccer\Exception
 */
class ApiRequestException extends Exception
{
}
