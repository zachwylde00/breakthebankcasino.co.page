<?php
class ApiRequestException extends Exception 
{}
?>