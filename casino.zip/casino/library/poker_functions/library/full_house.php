<?php
function FullHouse($player_cards, $player_score){
	if(full_house_check($player_cards, '1', '2')){
		return($player_score <= 0 ? 70 : $player_score);
	}else if(full_house_check($player_cards, '1', '3')){
		return($player_score <= 0 ? 70 : $player_score);
	}else if(full_house_check($player_cards, '1', '4')){
		return($player_score <= 0 ? 70 : $player_score);
	}else if(full_house_check($player_cards, '1', '5')){
		return($player_score <= 0 ? 70 : $player_score);
	}else if(full_house_check($player_cards, '1', '6')){
		return($player_score <= 0 ? 70 : $player_score);
	}else if(full_house_check($player_cards, '1', '7')){
		return($player_score <= 0 ? 70 : $player_score);
	}else if(full_house_check($player_cards, '1', '8')){
		return($player_score <= 0 ? 70 : $player_score);
	}else if(full_house_check($player_cards, '1', '9')){
		return($player_score <= 0 ? 70 : $player_score);
	}else if(full_house_check($player_cards, '1', '10')){
		return($player_score <= 0 ? 70 : $player_score);
	}else if(full_house_check($player_cards, '1', '11')){
		return($player_score <= 0 ? 70 : $player_score);
	}else if(full_house_check($player_cards, '1', '12')){
		return($player_score <= 0 ? 70 : $player_score);
	}else if(full_house_check($player_cards, '1', '13')){
		return($player_score <= 0 ? 70 : $player_score);
	}else if(full_house_check($player_cards, '2', '1')){
		return($player_score <= 0 ? 70 : $player_score);
	}else if(full_house_check($player_cards, '2', '3')){
		return($player_score <= 0 ? 70 : $player_score);
	}else if(full_house_check($player_cards, '2', '4')){
		return($player_score <= 0 ? 70 : $player_score);
	}else if(full_house_check($player_cards, '2', '5')){
		return($player_score <= 0 ? 70 : $player_score);
	}else if(full_house_check($player_cards, '2', '6')){
		return($player_score <= 0 ? 70 : $player_score);
	}else if(full_house_check($player_cards, '2', '7')){
		return($player_score <= 0 ? 70 : $player_score);
	}else if(full_house_check($player_cards, '2', '8')){
		return($player_score <= 0 ? 70 : $player_score);
	}else if(full_house_check($player_cards, '2', '9')){
		return($player_score <= 0 ? 70 : $player_score);
	}else if(full_house_check($player_cards, '2', '10')){
		return($player_score <= 0 ? 70 : $player_score);
	}else if(full_house_check($player_cards, '2', '11')){
		return($player_score <= 0 ? 70 : $player_score);
	}else if(full_house_check($player_cards, '2', '12')){
		return($player_score <= 0 ? 70 : $player_score);
	}else if(full_house_check($player_cards, '2', '13')){
		return($player_score <= 0 ? 70 : $player_score);
	}else if(full_house_check($player_cards, '3', '1')){
		return($player_score <= 0 ? 70 : $player_score);
	}else if(full_house_check($player_cards, '3', '2')){
		return($player_score <= 0 ? 70 : $player_score);
	}else if(full_house_check($player_cards, '3', '4')){
		return($player_score <= 0 ? 70 : $player_score);
	}else if(full_house_check($player_cards, '3', '5')){
		return($player_score <= 0 ? 70 : $player_score);
	}else if(full_house_check($player_cards, '3', '6')){
		return($player_score <= 0 ? 70 : $player_score);
	}else if(full_house_check($player_cards, '3', '7')){
		return($player_score <= 0 ? 70 : $player_score);
	}else if(full_house_check($player_cards, '3', '8')){
		return($player_score <= 0 ? 70 : $player_score);
	}else if(full_house_check($player_cards, '3', '9')){
		return($player_score <= 0 ? 70 : $player_score);
	}else if(full_house_check($player_cards, '3', '10')){
		return($player_score <= 0 ? 70 : $player_score);
	}else if(full_house_check($player_cards, '3', '11')){
		return($player_score <= 0 ? 70 : $player_score);
	}else if(full_house_check($player_cards, '3', '12')){
		return($player_score <= 0 ? 70 : $player_score);
	}else if(full_house_check($player_cards, '3', '13')){
		return($player_score <= 0 ? 70 : $player_score);
	}else if(full_house_check($player_cards, '4', '1')){
		return($player_score <= 0 ? 70 : $player_score);
	}else if(full_house_check($player_cards, '4', '2')){
		return($player_score <= 0 ? 70 : $player_score);
	}else if(full_house_check($player_cards, '4', '3')){
		return($player_score <= 0 ? 70 : $player_score);
	}else if(full_house_check($player_cards, '4', '5')){
		return($player_score <= 0 ? 70 : $player_score);
	}else if(full_house_check($player_cards, '4', '6')){
		return($player_score <= 0 ? 70 : $player_score);
	}else if(full_house_check($player_cards, '4', '7')){
		return($player_score <= 0 ? 70 : $player_score);
	}else if(full_house_check($player_cards, '4', '8')){
		return($player_score <= 0 ? 70 : $player_score);
	}else if(full_house_check($player_cards, '4', '9')){
		return($player_score <= 0 ? 70 : $player_score);
	}else if(full_house_check($player_cards, '4', '10')){
		return($player_score <= 0 ? 70 : $player_score);
	}else if(full_house_check($player_cards, '4', '11')){
		return($player_score <= 0 ? 70 : $player_score);
	}else if(full_house_check($player_cards, '4', '12')){
		return($player_score <= 0 ? 70 : $player_score);
	}else if(full_house_check($player_cards, '4', '13')){
		return($player_score <= 0 ? 70 : $player_score);
	}else if(full_house_check($player_cards, '5', '1')){
		return($player_score <= 0 ? 70 : $player_score);
	}else if(full_house_check($player_cards, '5', '2')){
		return($player_score <= 0 ? 70 : $player_score);
	}else if(full_house_check($player_cards, '5', '3')){
		return($player_score <= 0 ? 70 : $player_score);
	}else if(full_house_check($player_cards, '5', '4')){
		return($player_score <= 0 ? 70 : $player_score);
	}else if(full_house_check($player_cards, '5', '6')){
		return($player_score <= 0 ? 70 : $player_score);
	}else if(full_house_check($player_cards, '5', '7')){
		return($player_score <= 0 ? 70 : $player_score);
	}else if(full_house_check($player_cards, '5', '8')){
		return($player_score <= 0 ? 70 : $player_score);
	}else if(full_house_check($player_cards, '5', '9')){
		return($player_score <= 0 ? 70 : $player_score);
	}else if(full_house_check($player_cards, '5', '10')){
		return($player_score <= 0 ? 70 : $player_score);
	}else if(full_house_check($player_cards, '5', '11')){
		return($player_score <= 0 ? 70 : $player_score);
	}else if(full_house_check($player_cards, '5', '12')){
		return($player_score <= 0 ? 70 : $player_score);
	}else if(full_house_check($player_cards, '5', '13')){
		return($player_score <= 0 ? 70 : $player_score);
	}else if(full_house_check($player_cards, '6', '1')){
		return($player_score <= 0 ? 70 : $player_score);
	}else if(full_house_check($player_cards, '6', '2')){
		return($player_score <= 0 ? 70 : $player_score);
	}else if(full_house_check($player_cards, '6', '3')){
		return($player_score <= 0 ? 70 : $player_score);
	}else if(full_house_check($player_cards, '6', '4')){
		return($player_score <= 0 ? 70 : $player_score);
	}else if(full_house_check($player_cards, '6', '5')){
		return($player_score <= 0 ? 70 : $player_score);
	}else if(full_house_check($player_cards, '6', '7')){
		return($player_score <= 0 ? 70 : $player_score);
	}else if(full_house_check($player_cards, '6', '8')){
		return($player_score <= 0 ? 70 : $player_score);
	}else if(full_house_check($player_cards, '6', '9')){
		return($player_score <= 0 ? 70 : $player_score);
	}else if(full_house_check($player_cards, '6', '10')){
		return($player_score <= 0 ? 70 : $player_score);
	}else if(full_house_check($player_cards, '6', '11')){
		return($player_score <= 0 ? 70 : $player_score);
	}else if(full_house_check($player_cards, '6', '12')){
		return($player_score <= 0 ? 70 : $player_score);
	}else if(full_house_check($player_cards, '6', '13')){
		return($player_score <= 0 ? 70 : $player_score);
	}else if(full_house_check($player_cards, '7', '1')){
		return($player_score <= 0 ? 70 : $player_score);
	}else if(full_house_check($player_cards, '7', '2')){
		return($player_score <= 0 ? 70 : $player_score);
	}else if(full_house_check($player_cards, '7', '3')){
		return($player_score <= 0 ? 70 : $player_score);
	}else if(full_house_check($player_cards, '7', '4')){
		return($player_score <= 0 ? 70 : $player_score);
	}else if(full_house_check($player_cards, '7', '5')){
		return($player_score <= 0 ? 70 : $player_score);
	}else if(full_house_check($player_cards, '7', '6')){
		return($player_score <= 0 ? 70 : $player_score);
	}else if(full_house_check($player_cards, '7', '8')){
		return($player_score <= 0 ? 70 : $player_score);
	}else if(full_house_check($player_cards, '7', '9')){
		return($player_score <= 0 ? 70 : $player_score);
	}else if(full_house_check($player_cards, '7', '10')){
		return($player_score <= 0 ? 70 : $player_score);
	}else if(full_house_check($player_cards, '7', '11')){
		return($player_score <= 0 ? 70 : $player_score);
	}else if(full_house_check($player_cards, '7', '12')){
		return($player_score <= 0 ? 70 : $player_score);
	}else if(full_house_check($player_cards, '7', '13')){
		return($player_score <= 0 ? 70 : $player_score);
	}else if(full_house_check($player_cards, '8', '1')){
		return($player_score <= 0 ? 70 : $player_score);
	}else if(full_house_check($player_cards, '8', '2')){
		return($player_score <= 0 ? 70 : $player_score);
	}else if(full_house_check($player_cards, '8', '3')){
		return($player_score <= 0 ? 70 : $player_score);
	}else if(full_house_check($player_cards, '8', '4')){
		return($player_score <= 0 ? 70 : $player_score);
	}else if(full_house_check($player_cards, '8', '5')){
		return($player_score <= 0 ? 70 : $player_score);
	}else if(full_house_check($player_cards, '8', '6')){
		return($player_score <= 0 ? 70 : $player_score);
	}else if(full_house_check($player_cards, '8', '7')){
		return($player_score <= 0 ? 70 : $player_score);
	}else if(full_house_check($player_cards, '8', '9')){
		return($player_score <= 0 ? 70 : $player_score);
	}else if(full_house_check($player_cards, '8', '10')){
		return($player_score <= 0 ? 70 : $player_score);
	}else if(full_house_check($player_cards, '8', '11')){
		return($player_score <= 0 ? 70 : $player_score);
	}else if(full_house_check($player_cards, '8', '12')){
		return($player_score <= 0 ? 70 : $player_score);
	}else if(full_house_check($player_cards, '8', '13')){
		return($player_score <= 0 ? 70 : $player_score);
	}else if(full_house_check($player_cards, '9', '1')){
		return($player_score <= 0 ? 70 : $player_score);
	}else if(full_house_check($player_cards, '9', '2')){
		return($player_score <= 0 ? 70 : $player_score);
	}else if(full_house_check($player_cards, '9', '3')){
		return($player_score <= 0 ? 70 : $player_score);
	}else if(full_house_check($player_cards, '9', '4')){
		return($player_score <= 0 ? 70 : $player_score);
	}else if(full_house_check($player_cards, '9', '5')){
		return($player_score <= 0 ? 70 : $player_score);
	}else if(full_house_check($player_cards, '9', '6')){
		return($player_score <= 0 ? 70 : $player_score);
	}else if(full_house_check($player_cards, '9', '7')){
		return($player_score <= 0 ? 70 : $player_score);
	}else if(full_house_check($player_cards, '9', '8')){
		return($player_score <= 0 ? 70 : $player_score);
	}else if(full_house_check($player_cards, '9', '10')){
		return($player_score <= 0 ? 70 : $player_score);
	}else if(full_house_check($player_cards, '9', '11')){
		return($player_score <= 0 ? 70 : $player_score);
	}else if(full_house_check($player_cards, '9', '12')){
		return($player_score <= 0 ? 70 : $player_score);
	}else if(full_house_check($player_cards, '9', '13')){
		return($player_score <= 0 ? 70 : $player_score);
	}else if(full_house_check($player_cards, '10', '1')){
		return($player_score <= 0 ? 70 : $player_score);
	}else if(full_house_check($player_cards, '10', '2')){
		return($player_score <= 0 ? 70 : $player_score);
	}else if(full_house_check($player_cards, '10', '3')){
		return($player_score <= 0 ? 70 : $player_score);
	}else if(full_house_check($player_cards, '10', '4')){
		return($player_score <= 0 ? 70 : $player_score);
	}else if(full_house_check($player_cards, '10', '5')){
		return($player_score <= 0 ? 70 : $player_score);
	}else if(full_house_check($player_cards, '10', '6')){
		return($player_score <= 0 ? 70 : $player_score);
	}else if(full_house_check($player_cards, '10', '7')){
		return($player_score <= 0 ? 70 : $player_score);
	}else if(full_house_check($player_cards, '10', '8')){
		return($player_score <= 0 ? 70 : $player_score);
	}else if(full_house_check($player_cards, '10', '9')){
		return($player_score <= 0 ? 70 : $player_score);
	}else if(full_house_check($player_cards, '10', '11')){
		return($player_score <= 0 ? 70 : $player_score);
	}else if(full_house_check($player_cards, '10', '12')){
		return($player_score <= 0 ? 70 : $player_score);
	}else if(full_house_check($player_cards, '10', '13')){
		return($player_score <= 0 ? 70 : $player_score);
	}else if(full_house_check($player_cards, '11', '1')){
		return($player_score <= 0 ? 70 : $player_score);
	}else if(full_house_check($player_cards, '11', '2')){
		return($player_score <= 0 ? 70 : $player_score);
	}else if(full_house_check($player_cards, '11', '3')){
		return($player_score <= 0 ? 70 : $player_score);
	}else if(full_house_check($player_cards, '11', '4')){
		return($player_score <= 0 ? 70 : $player_score);
	}else if(full_house_check($player_cards, '11', '5')){
		return($player_score <= 0 ? 70 : $player_score);
	}else if(full_house_check($player_cards, '11', '6')){
		return($player_score <= 0 ? 70 : $player_score);
	}else if(full_house_check($player_cards, '11', '7')){
		return($player_score <= 0 ? 70 : $player_score);
	}else if(full_house_check($player_cards, '11', '8')){
		return($player_score <= 0 ? 70 : $player_score);
	}else if(full_house_check($player_cards, '11', '9')){
		return($player_score <= 0 ? 70 : $player_score);
	}else if(full_house_check($player_cards, '11', '10')){
		return($player_score <= 0 ? 70 : $player_score);
	}else if(full_house_check($player_cards, '11', '12')){
		return($player_score <= 0 ? 70 : $player_score);
	}else if(full_house_check($player_cards, '11', '13')){
		return($player_score <= 0 ? 70 : $player_score);
	}else if(full_house_check($player_cards, '12', '1')){
		return($player_score <= 0 ? 70 : $player_score);
	}else if(full_house_check($player_cards, '12', '2')){
		return($player_score <= 0 ? 70 : $player_score);
	}else if(full_house_check($player_cards, '12', '3')){
		return($player_score <= 0 ? 70 : $player_score);
	}else if(full_house_check($player_cards, '12', '4')){
		return($player_score <= 0 ? 70 : $player_score);
	}else if(full_house_check($player_cards, '12', '5')){
		return($player_score <= 0 ? 70 : $player_score);
	}else if(full_house_check($player_cards, '12', '6')){
		return($player_score <= 0 ? 70 : $player_score);
	}else if(full_house_check($player_cards, '12', '7')){
		return($player_score <= 0 ? 70 : $player_score);
	}else if(full_house_check($player_cards, '12', '8')){
		return($player_score <= 0 ? 70 : $player_score);
	}else if(full_house_check($player_cards, '12', '9')){
		return($player_score <= 0 ? 70 : $player_score);
	}else if(full_house_check($player_cards, '12', '10')){
		return($player_score <= 0 ? 70 : $player_score);
	}else if(full_house_check($player_cards, '12', '11')){
		return($player_score <= 0 ? 70 : $player_score);
	}else if(full_house_check($player_cards, '12', '13')){
		return($player_score <= 0 ? 70 : $player_score);
	}else if(full_house_check($player_cards, '13', '1')){
		return($player_score <= 0 ? 70 : $player_score);
	}else if(full_house_check($player_cards, '13', '2')){
		return($player_score <= 0 ? 70 : $player_score);
	}else if(full_house_check($player_cards, '13', '3')){
		return($player_score <= 0 ? 70 : $player_score);
	}else if(full_house_check($player_cards, '13', '4')){
		return($player_score <= 0 ? 70 : $player_score);
	}else if(full_house_check($player_cards, '13', '5')){
		return($player_score <= 0 ? 70 : $player_score);
	}else if(full_house_check($player_cards, '13', '6')){
		return($player_score <= 0 ? 70 : $player_score);
	}else if(full_house_check($player_cards, '13', '7')){
		return($player_score <= 0 ? 70 : $player_score);
	}else if(full_house_check($player_cards, '13', '8')){
		return($player_score <= 0 ? 70 : $player_score);
	}else if(full_house_check($player_cards, '13', '9')){
		return($player_score <= 0 ? 70 : $player_score);
	}else if(full_house_check($player_cards, '13', '10')){
		return($player_score <= 0 ? 70 : $player_score);
	}else if(full_house_check($player_cards, '13', '11')){
		return($player_score <= 0 ? 70 : $player_score);
	}else if(full_house_check($player_cards, '13', '12')){
		return($player_score <= 0 ? 70 : $player_score);
	}else{
		return($player_score);
	}
}
?>