<?php

if(is_file(scriptdir.ds."library".ds."classes".ds."jdate.php")&&file_exists(scriptdir.ds."library".ds."classes".ds."jdate.php")):require_once(scriptdir.ds."library".ds."classes".ds."jdate.php");endif;
?>